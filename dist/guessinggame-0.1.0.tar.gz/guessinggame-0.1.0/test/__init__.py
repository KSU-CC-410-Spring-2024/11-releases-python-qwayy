"""Test Package for Guessing Game.

Author: Jacque Jones sey91mone@ksu.edu
Version: 0.1
"""
